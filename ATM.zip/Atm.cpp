#include <iostream>
using namespace std;
int opitions(){
	cout<<"--------------- ATM Mchine -------------------!"<<endl;
	cout<<"1: Deposite Your Money"<<endl;
	cout<<"2: Check Your Balance"<<endl;
	cout<<"3: Withdraw Your Money"<<endl;
	cout<<"4: Transfer Your Money"<<endl;
	cout<<"5: Exit "<<endl;
	cout<<"----------------Opition---------------"<<endl;
	return 0;
}
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
		int n;
	int balance=500;
	do{
	cout<<opitions()<<endl;
 
	cout<<"Chose your opition"<<endl;
	cin>>n;
	if(n==1){
		cout<<"Deposite your money\n";
		long d;
		cin>>d;
		balance= balance+d;
	}
	else if(n==2){
		cout<<"Your balance is "<< balance <<endl;
//		int d;
//		cin>>d;
//		balance +=d;
	}
	else if(n==3){
		cout<<"Enter your ammount which do want to withdraw "<<endl;
		int w;
		cin>>w;
		balance = balance -w;
//		int d;
//		cin>>d;
//		balance +=d;
	}
	
	else if(n==4){
		int t,CNIC;
		cout<<"Enter your amount Want to transfer "<< endl;
		cin>>t;
		cout<<"Enter CNIC Wher you want to transfer "<< endl;
		cin>>CNIC;
		balance = balance -t;
		cout<<balance<<endl;
		cout<<"Thanks For using "<<endl;
//		int d;
//		cin>>d;
//		balance +=d;
	}
	
		else if(n==5){
		cout<<"Do you want to exit Y/N "<<endl;
		char ch;
		cin>>ch;
//		if(ch=='Yes'){
//			
//			
//			cout<<"tanks for using";
//			break;
//		}
//		else if{
//			cout<<"Ok good";
////			continue;
//		}
//		cin>>d;
//		i
//		balance +=d;
	}
	
	else{
		cout<<"You enter a wrong ";
	}
	
	
	}while(n!=5);
	
	
	

	return 0;
}
